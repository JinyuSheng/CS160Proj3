// Much of this is straight from
// https://medium.com/framer-js/ca55fc7cfc61

// Module and general methods
FramerToolbelt = (function(psdObj) {

  var demoViewEls = [];

  return {

    storePsdOrigins: function() {
      for (var i in psdObj) {
        psdObj[i].storeOrigins();
      }
    },

    createGlobalsFromPsd: function() {
      for (var i in psdObj) {
        window[i] = psdObj[i];
      }
    },

    attachToDemoScreen: function() {
      for (var i in arguments) {
        demoViewEls.push(arguments[i]);
      }
    },

    desktopDemoMode: function() {
      for (var i in demoViewEls) {
        demoViewEls[i].superView = screen;
      }
    }

  };

})(PSD);



// View object prototype methods
View.prototype.storeOrigins = function() {
  this.origin = this.frame;
}

View.prototype.hide = function() {
  this.visible = false;
  this.opacity = 0;
}

View.prototype.show = function() {
  this.visible = true;
  this.opacity = 1;
}

View.prototype.fadeIn = function(ms) {
  var view = this;
  view.visible = true;
  view.opacity = 0;
  if (ms === undefined) ms = 500;
  view.animate({
    properties: {
      opacity: 1
    },
    time: ms
  });
}

View.prototype.fadeOut = function(ms) {
  var view = this;
  if (ms === undefined) ms = 500;
  view.animate({
    properties: {
      opacity: 0
    },
    time: ms
  });
  utils.delay(ms, function() {
    view.visible = false;
  });
}

View.prototype.standardAnim = function(props) {
  return this.animate({
    time: 500,
    curve: 'ease-in-out',
    properties: props
  });
}
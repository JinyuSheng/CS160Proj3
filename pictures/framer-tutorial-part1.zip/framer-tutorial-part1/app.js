// globals
var APP = APP || {};
APP.isNavOpen = false;

// create global variables for views
FramerToolbelt.createGlobalsFromPsd();
// settings for desktop demo mode
FramerToolbelt.attachToDemoScreen(Menu, Main);

// hamburger menu show/hide functionality
var toggleMenu = function() {
  if (APP.isNavOpen === false) {
    Main.animate({
      properties: {x: 540},
      time: 300
    });
  } else {
    Main.animate({
      properties: {x: 0},
      time: 300
    });
  }
  APP.isNavOpen = !APP.isNavOpen;
}
BtnMenu.on('click', toggleMenu);
Menu.on('click', toggleMenu);
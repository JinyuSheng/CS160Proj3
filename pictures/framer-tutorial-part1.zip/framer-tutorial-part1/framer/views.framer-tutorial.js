		window.FramerPS = window.FramerPS || {};
		window.FramerPS['framer-tutorial'] = [
	{
		"id": 432,
		"name": "Menu",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 640,
			"height": 1136
		},
		"maskFrame": null,
		"image": {
			"path": "images/Menu.png",
			"frame": {
				"x": 0,
				"y": 0,
				"width": 640,
				"height": 1136
			}
		},
		"imageType": "png",
		"children": [
			
		],
		"modification": "811904116"
	},
	{
		"id": 434,
		"name": "Main",
		"layerFrame": {
			"x": 0,
			"y": 0,
			"width": 640,
			"height": 1136
		},
		"maskFrame": null,
		"image": null,
		"imageType": null,
		"children": [
			{
				"id": 166,
				"name": "topbar",
				"layerFrame": {
					"x": 0,
					"y": -40,
					"width": 640,
					"height": 128
				},
				"maskFrame": null,
				"image": {
					"path": "images/topbar.png",
					"frame": {
						"x": 0,
						"y": 0,
						"width": 640,
						"height": 88
					}
				},
				"imageType": "png",
				"children": [
					{
						"id": 164,
						"name": "BtnMenu",
						"layerFrame": {
							"x": 0,
							"y": 0,
							"width": 640,
							"height": 1136
						},
						"maskFrame": null,
						"image": {
							"path": "images/BtnMenu.png",
							"frame": {
								"x": 0,
								"y": 0,
								"width": 100,
								"height": 88
							}
						},
						"imageType": "png",
						"children": [
							
						],
						"modification": "383067461"
					}
				],
				"modification": "1265760958"
			},
			{
				"id": 445,
				"name": "Match",
				"layerFrame": {
					"x": 0,
					"y": 0,
					"width": 640,
					"height": 1136
				},
				"maskFrame": null,
				"image": null,
				"imageType": null,
				"children": [
					{
						"id": 157,
						"name": "content",
						"layerFrame": {
							"x": 0,
							"y": 0,
							"width": 640,
							"height": 1136
						},
						"maskFrame": null,
						"image": null,
						"imageType": null,
						"children": [
							{
								"id": 555,
								"name": "controls",
								"layerFrame": {
									"x": 0,
									"y": 0,
									"width": 640,
									"height": 1136
								},
								"maskFrame": null,
								"image": null,
								"imageType": null,
								"children": [
									{
										"id": 562,
										"name": "no",
										"layerFrame": {
											"x": 0,
											"y": 0,
											"width": 640,
											"height": 1136
										},
										"maskFrame": null,
										"image": {
											"path": "images/no.png",
											"frame": {
												"x": 135,
												"y": 920,
												"width": 140,
												"height": 140
											}
										},
										"imageType": "png",
										"children": [
											
										],
										"modification": "837189143"
									},
									{
										"id": 560,
										"name": "yes",
										"layerFrame": {
											"x": 0,
											"y": 0,
											"width": 640,
											"height": 1136
										},
										"maskFrame": null,
										"image": {
											"path": "images/yes.png",
											"frame": {
												"x": 363,
												"y": 920,
												"width": 140,
												"height": 140
											}
										},
										"imageType": "png",
										"children": [
											
										],
										"modification": "836189683"
									}
								],
								"modification": "1236204089"
							},
							{
								"id": 273,
								"name": "card0",
								"layerFrame": {
									"x": 0,
									"y": 0,
									"width": 640,
									"height": 1136
								},
								"maskFrame": null,
								"image": {
									"path": "images/card0.png",
									"frame": {
										"x": 30,
										"y": 118,
										"width": 580,
										"height": 760
									}
								},
								"imageType": "png",
								"children": [
									
								],
								"modification": "203879598"
							},
							{
								"id": 335,
								"name": "card1",
								"layerFrame": {
									"x": 0,
									"y": 0,
									"width": 640,
									"height": 1136
								},
								"maskFrame": null,
								"image": {
									"path": "images/card1.png",
									"frame": {
										"x": 30,
										"y": 118,
										"width": 580,
										"height": 760
									}
								},
								"imageType": "png",
								"children": [
									
								],
								"modification": "2084868264"
							},
							{
								"id": 366,
								"name": "card2",
								"layerFrame": {
									"x": 0,
									"y": 0,
									"width": 640,
									"height": 1136
								},
								"maskFrame": null,
								"image": null,
								"imageType": null,
								"children": [
									
								],
								"modification": "0"
							}
						],
						"modification": "84496949"
					},
					{
						"id": 171,
						"name": "background",
						"layerFrame": {
							"x": 0,
							"y": 0,
							"width": 640,
							"height": 1136
						},
						"maskFrame": null,
						"image": {
							"path": "images/background.png",
							"frame": {
								"x": 0,
								"y": 0,
								"width": 640,
								"height": 1136
							}
						},
						"imageType": "png",
						"children": [
							
						],
						"modification": "1733579966"
					}
				],
				"modification": "602535109"
			}
		],
		"modification": "215535879"
	}
]